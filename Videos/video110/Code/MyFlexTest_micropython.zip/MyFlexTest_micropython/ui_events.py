# Your callbacks for "Call function" events.
# LCD Wizard writes the stubs; keep your own copy once you have filled them in.
#
# e is the LVGL event (e.get_code(), e.get_target_obj()), or None when an
# automation called the function.

import lvgl as lv


def count_changed_cb(e):
    # TODO: your code here
    pass

def reset_cb(e):
    # TODO: your code here
    pass

def save_cb(e):
    # TODO: your code here
    pass

def ta_clear_cb(e):
    # TODO: your code here
    pass

def update_chart_cb(e):
    # TODO: your code here
    pass
