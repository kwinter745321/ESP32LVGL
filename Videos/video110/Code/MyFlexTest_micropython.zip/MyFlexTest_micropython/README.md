# MyFlexTest - MicroPython

An LVGL user interface designed in [LCD Wizard](https://lcdwizard.online/) for **Custom / breadboard wiring**, exported
as MicroPython for [lvgl_micropython](https://github.com/lvgl-micropython/lvgl_micropython)
(LVGL 9.4.0).

- Panel: ST7796 / ST7796S 320x480, rotation 90 degrees
- Touch: XPT2046
- Screens: Screen1, Screen2, Screen3

## 1. Firmware, with this UI frozen into it

lvgl_micropython compiles the display and touch drivers into the firmware, so it is
built for this board - and the same build can take the UI's Python with it.
`manifest.py` freezes every module here except `main.py`, so they run from flash
and the board needs no RAM to compile them. Importing the largest of them as a .py
instead needs about 37 KB free while it compiles.

It needs Linux or macOS (on Windows, WSL) with the ESP-IDF prerequisites in
lvgl_micropython's README.

```bash
git clone https://github.com/lvgl-micropython/lvgl_micropython
cd lvgl_micropython
git checkout d2d26467    # the version this export was written against
python3 make.py esp32 BOARD=ESP32_GENERIC_S3 BOARD_VARIANT=SPIRAM_OCT --flash-size=16 DISPLAY=st7796 INDEV=xpt2046 FROZEN_MANIFEST=/path/to/MyFlexTest_micropython/manifest.py deploy
```

`FROZEN_MANIFEST` wants the full path to `manifest.py` in this folder. `deploy` flashes
the board once the build finishes (add `PORT=/dev/ttyUSB0` if it is not found). `--flash-size` and the PSRAM variant are for an N16R8 module, as set on the Hardware tab.
Change the design and you build again.

The frozen UI is part of the firmware image, and make.py sizes the app partition to
fit it - the partition layout on the Hardware tab is for the Arduino export. The
filesystem the next step copies to gets what is left of the flash, so a large design
on a 4 MB module leaves less room there (`mpremote df` shows it).

## 2. Copy what is not frozen

With [mpremote](https://docs.micropython.org/en/latest/reference/mpremote.html):

```bash
pip install mpremote
mpremote cp main.py :
mpremote cp -r fonts :
mpremote reset
```

A `.py` copied to the board replaces the frozen module of the same name, so
`ui_events.py` (or anything else) can be changed without a rebuild.

**Without freezing** - a board with PSRAM and a small design - build the firmware
without `FROZEN_MANIFEST` and copy everything: `mpremote cp -r . :`.

`main.py` runs at boot and brings the screen up. The UI runs on an LVGL timer, so
the REPL stays free: `mpremote repl`, then for example `import ui` and poke at
`ui.ui_Screen1`.

On the first boot the resistive panel asks you to tap a few targets. The result is
kept in NVS; `board.S.indev.calibrate()` runs it again.

## What is here

| File | What it does |
|---|---|
| `main.py` | Starts the board, the S: drive for fonts and images, the UI and the task handler |
| `board.py` | Display, touch and backlight bring-up - pins and bus settings at the top |
| `ui.py` | Every object as a module global, the theme, and `init()` |
| `ui_Screen1.py` | Screen "Screen1" |
| `ui_Screen2.py` | Screen "Screen2" |
| `ui_Screen3.py` | Screen "Screen3" |
| `ui_helpers.py` | What event code calls: flags, screen changes, increments |
| `ui_events.py` | Stubs for your "Call function" events - fill these in |
| `ui_fonts.py` | Fonts loaded from `/fonts`, and a `UI_ICON_*` string per icon |
| `manifest.py` | Freezes the modules above (all but `main.py`) into the firmware |
| `fonts/` | Fonts the firmware does not have built in, as LVGL binary fonts |

## Differences from the Arduino export

- Fonts other than Montserrat 12, 14 and 16 are files in `/fonts`, loaded at start-up.
- Images are always files, including ones set to compile in.
- Custom calendar day names are not available; LVGL's own are shown.
- Encoder and button inputs are not exported yet, nor the BME280, BMP280, SCD4x, VL53L0X
  and CAN bus among the peripherals. The others, and every I/O expander, are a driver
  module each, written from the Arduino library or driver that reads the same part.
- A deleted screen's objects go back to `None`, so an event aimed at one is skipped
  instead of touching freed memory.

## Something wrong?

- **Blank or white screen:** check the pins at the top of `board.py`, and try the other
  `display.init()` type if the driver has two.
- **Colours inverted or red and blue swapped:** `set_color_inversion()` and
  `color_byte_order` in `board.py`.
- **A font missing:** `ui_fonts` prints which file did not load - check `/fonts` was copied.
- **An error in the REPL, then the screen stops:** the task handler stops on an exception;
  the traceback names the file and line.

---

Made with [LCD Wizard](https://lcdwizard.online/) - the LVGL designer for Arduino and MicroPython display boards.
