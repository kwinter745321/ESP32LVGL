# Libraries for MyGame

Everything the generated sketch needs, with the exact names to search for.
Generated 2026-10-22 19:27.

## Install these

| Library | Author | Search for this in Arduino Library Manager | Version | Needed by |
|---|---|---|---|---|
| [lvgl](https://github.com/lvgl/lvgl) | LVGL Kft. | `lvgl` | **9.4.0** | The GUI library the whole UI is built on |
| [TFT_eSPI](https://github.com/Bodmer/TFT_eSPI) | Bodmer | `TFT_eSPI` | newest | Drives the ST7796 / ST7796S panel |

Where a version is given, install that one: the export was built against it, and a
newer release is not known to compile.

> **lvgl** - Configured by the generated lv_conf.h, which the ESP32 core reads from the sketch folder - nothing to copy.

> **TFT_eSPI** - Configured by the generated User_Setup.h, which the ESP32 core reads from the sketch folder on the Arduino IDE - nothing to copy. PlatformIO takes the same settings from platformio.ini.

## Already on your machine

Bundled with the board core - nothing to install.

- **SPI** - XPT2046 is read directly by the generated sketch - no driver library needed

## Installing

### Arduino IDE

**Sketch > Include Library > Manage Libraries**, then search for each name in the
table above and click Install. Where the table gives a version, pick it from the list beside the Install button first.

### Arduino CLI

```bash
arduino-cli lib install "lvgl@9.4.0"
arduino-cli lib install "TFT_eSPI"

arduino-cli compile --fqbn esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,PartitionScheme=custom .
```

### PlatformIO

Already written into `platformio.ini`, so `pio run` fetches them for you:

```ini
lib_deps =
    lvgl/lvgl@9.4.0
    bodmer/TFT_eSPI
```

## Versions this project was generated against

| | |
|---|---|
| LVGL | 9.4.0 (API 9.x) |
| Board core | ESP32-S3 - `esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,PartitionScheme=custom` |
| Graphics backend | TFT_eSPI |

LVGL 8 and 9 are not source compatible. If you switch major version, re-export
from LCD Wizard rather than hand-patching the generated files.
